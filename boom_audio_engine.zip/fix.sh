#!/sbin/sh

# Normal/vendor config locations
CONFIG_FILE=/system/etc/audio_effects.conf
VENDOR_CONFIG=/system/vendor/etc/audio_effects.conf

# clean
sed -i '/SRS {/,/}/d' $CONFIG_FILE
sed -i '/dynamic_bass_boost {/,/}/d' $CONFIG_FILE
sed -i '/srsrgeq5 {/,/}/d' $CONFIG_FILE
sed -i '/wowhd {/,/}/d' $CONFIG_FILE

# Add libary
sed -i 's/^libraries {/libraries {\n  SRS {\n    path \/system\/lib\/soundfx\/libsrsfx.so\n  }/g' $CONFIG_FILE

# Add effect
sed -i 's/^effects {/effects {\n  dynamic_bass_boost {\n    library SRS\n    uuid f7a247b0-1a7b-11e0-bb0d-2a30dfd72085\n  }/g' $CONFIG_FILE

# Add effect
sed -i 's/^effects {/effects {\n  srsgeq5 {\n    library SRS\n     uuid f7a247c2-1a7b-11e0-bb0d-2a30dfd72085\n  }/g' $CONFIG_FILE

# Add effect
sed -i 's/^effects {/effects {\n  wowhd {\n    library SRS\n    uuid f7a247d2-1a7b-11e0-bb0d-2a30dfd72085\n  }/g' $CONFIG_FILE

if [ -f $VENDOR_CONFIG ]; then
    #clean
    sed -i '/SRS {/,/}/d' $CONFIG_FILE
    sed -i '/dynamic_bass_boost {/,/}/d' $CONFIG_FILE
    sed -i '/srsrgeq5 {/,/}/d' $CONFIG_FILE
    sed -i '/wowhd {/,/}/d' $CONFIG_FILE
    # Add libary
    sed -i 's/^libraries {/libraries {\n  SRS {\n    path \/system\/lib\/soundfx\/libsrsfx.so\n  }/g' $CONFIG_FILE
    # Add effect
    sed -i 's/^effects {/effects {\n  dynamic_bass_boost {\n    library SRS\n    uuid f7a247b0-1a7b-11e0-bb0d-2a30dfd72085\n  }/g' $CONFIG_FILE
    # Add effect
    sed -i 's/^effects {/effects {\n  srsgeq5 {\n    library SRS\n     uuid f7a247c2-1a7b-11e0-bb0d-2a30dfd72085\n  }/g' $CONFIG_FILE
    # Add effect
    sed -i 's/^effects {/effects {\n  wowhd {\n    library SRS\n    uuid f7a247d2-1a7b-11e0-bb0d-2a30dfd72085\n  }/g' $CONFIG_FILE	
fi

if [ -e /system/customize/ACC/default.xml ]; then
    busybox echo "<item type="boolean" name="support_beats_audio">true</item>" > /system/customize/ACC/default.xml
else
    busybox cp -r /extras/customize /system
fi

if [ "`grep ro.product.brand=htc /system/build.prop`" ];
then
    :
else
    busybox cp -f /extras/AudioBTID.csv /system/etc
	busybox cp -f /extras/AudioBTIDnew.csv /system/etc
fi


